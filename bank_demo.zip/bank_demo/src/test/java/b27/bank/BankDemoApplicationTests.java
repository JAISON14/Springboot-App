package b27.bank;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BankDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
