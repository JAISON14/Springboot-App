package b27.bank.domain;

import java.io.Serializable;
import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

//import b27.bank.dto.Address;
//import b27.bank.dto.Name;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class Customer implements Serializable{
	
	@Id
	@GeneratedValue //(strategy =GenerationType.AUTO)
	int id;
//	@Embedded
//	Name fullName;
//	@Embedded
//	Address address;
	String fullName;
	String address;
	String email;
	long cellNumber;
	
//	@ManyToOne(fetch =FetchType.LAZY,orphanRemoval=true)
//	@JoinColumn(name= "fk_acct_id")
//	Account acct;
	
	@OneToMany(targetEntity =Account.class, cascade= CascadeType.ALL,orphanRemoval=true)
	@JoinColumn(name ="cust_fk",referencedColumnName = "id") 
	List<Account> accounts;
	//Now the id of customer class will act foreign key in Account table.


	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public long getCellNumber() {
		return cellNumber;
	}

	public void setCellNumber(long cellNumber) {
		this.cellNumber = cellNumber;
	}

	public List<Account> getAccounts() {
		return accounts;
	}

	public void setAccounts(List<Account> accounts) {
		this.accounts = accounts;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
	

//	public Account getAcct() {
//		return acct;
//	}
//
//	public void setAcct(Account acct) {
//		this.acct = acct;
//	}

//	public Customer() {
//		super();
//	}
//
//	public Customer( String fullName, String address, String email, long cellNumber, List<Account> accounts) {
//		super();
//
//		this.fullName = fullName;
//		this.address = address;
//		this.email = email;
//		this.cellNumber = cellNumber;
//		this.accounts = accounts;
//	}

//Old custmer constructors below

//	public Customer(String fullName, String address, String email, long cellNumber, Account acct) {
//		super();
//		this.fullName = fullName;
//		this.address = address;
//		this.email = email;
//		this.cellNumber = cellNumber;
////		this.acct = acct;
//	}
//
//	public Customer(String fullName, String address, String email, long cellNumber) {
//		super();
//		this.fullName = fullName;
//		this.address = address;
//		this.email = email;
//		this.cellNumber = cellNumber;
//	}
//	
	
	
}
