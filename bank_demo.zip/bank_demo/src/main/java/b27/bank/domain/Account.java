package b27.bank.domain;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class Account implements Serializable{
	


	
//	@GeneratedValue(strategy =GenerationType.AUTO)
	@Id
	@GeneratedValue(strategy =GenerationType.AUTO)
	int id;
	
	String accountType;
	double balance;
	
//	@OneToMany(mappedBy = "acct", cascade= CascadeType.ALL, fetch=FetchType.LAZY, orphanRemoval=true)
//	Set<Customer> customers;
	
	
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public double getBalance() {
		return balance;
	}



	public void setBalance(double balance) {
		this.balance = balance;
	}


//	public Account() {
//		super();
//	}
//
//public Account( String accountType, double balance) {
//	super();
////	this.id = id;
//	this.accountType = accountType;
//	this.balance = balance;
//}




//Old constructor below

//	public Account(String accountType, double balance, Set<Customer> customers) {
//		super();
//		this.accountType = accountType;
//		this.balance = balance;
//		this.customers = customers;
//	}
//	

}
