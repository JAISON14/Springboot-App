package b27.bank.controller;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import b27.bank.util.CustomErrorType;
//import b27.bank.dao.CustomerRepository;
import b27.bank.domain.Account;
import b27.bank.domain.Customer;
import b27.bank.service.BankService;
import b27.bank.dto.TransactionRequest;
import b27.bank.dto.customerRequest;



@RestController
public class BankController {
	
	@Autowired
	BankService service;
	
//	@Autowired
//	CustomerRepository custRepo;
	
	@GetMapping("/")
	public String getDefaultResponse() {
		return("######### Welcome to Bank Case Study #############");
	}

//	@PostMapping("/account")
//	public ResponseEntity<?> saveNewAccount(@RequestBody Account acct){
//		ResponseEntity<?> response=new ResponseEntity<>(new CustomErrorType("Unable to create because unique constraint violation- Account"),HttpStatus.CONFLICT);
//	
//			Account savedAccount=service.createNewAccount(acct);
//			response=new ResponseEntity<>(savedAccount,HttpStatus.CREATED);
//
//		return response;
//
//	}
//	@PostMapping("/customer")
//	public ResponseEntity<?> saveCustomer(@RequestBody Customer cust){
//		ResponseEntity<?> response=new ResponseEntity<>(new CustomErrorType("Unable to create because unique constraint violation- Customer"),HttpStatus.CONFLICT);
//	
//			Customer savedCustomer=service.createNewCustomer(cust);
//			response=new ResponseEntity<>(savedCustomer,HttpStatus.CREATED);
//
//		return response;
//
//	}
	
	@GetMapping("/accounts/{id}")
	public ResponseEntity<?> findAccount(@PathVariable int id){
		ResponseEntity<?> response=new ResponseEntity<>(new CustomErrorType("Unable to find the Account with given id"),HttpStatus.NOT_FOUND);
		boolean isAccountExist=service.isAccountPresent(id);
		if(isAccountExist) {
		Optional<Account> foundAccount=service.findByAccountId(id);
		response=new ResponseEntity<>(foundAccount.get(),HttpStatus.OK);
		}
		return response;
	}
	
	@GetMapping("/customer/{id}")
	public ResponseEntity<?> findCustomer(@PathVariable int id){
		ResponseEntity<?> response=new ResponseEntity<>(new CustomErrorType("Unable to find the Customer with given id"),HttpStatus.NOT_FOUND);
		boolean isCustomerExist=service.isCustomerPresent(id);
		if(isCustomerExist) {
		Customer foundCustomer=service.findCustomer(id);
		response=new ResponseEntity<>(foundCustomer,HttpStatus.OK);
		}
		return response;

	}
	
	@GetMapping("/accounts")
	public ResponseEntity<?> findAllAccountDetails(){
		ResponseEntity<?> response=ResponseEntity.ok(service.findAllAccounts());
		return response;
	}
	
//	@GetMapping("/read/customers")
//	public ResponseEntity<?> displayCustomerList(){
//		ResponseEntity<?> response=ResponseEntity.ok(service.findAllCustomers());
//		return response;
//	}
	
	@PutMapping("/transaction")
	public ResponseEntity<?> transaction(@RequestBody TransactionRequest request){
		ResponseEntity<?> response=new ResponseEntity<>(new CustomErrorType("Transaction failed"),HttpStatus.NOT_FOUND);
		int result=service.transferFund(request.getFromAccount(),request.getToAccount(),request.getAmount());
		if(result==0) {
			response=ResponseEntity.ok("Transaction Successfull");
		}
		else if(result==1) {
			response=new ResponseEntity<>(new CustomErrorType("Transaction failed since fromAccount not found"),HttpStatus.NOT_FOUND);
		}		
		else if(result==2){
			response=new ResponseEntity<>(new CustomErrorType("Transaction failed due to insufficient balance"),HttpStatus.NOT_FOUND);				
		}
		else if(result==3){
			response=new ResponseEntity<>(new CustomErrorType("Transaction failed since toAccount not found"),HttpStatus.NOT_FOUND);		
		}	
		return response;
	}
	@PostMapping("/customer")
	public Customer customerRequest(@RequestBody customerRequest request){
//		ResponseEntity<?> response=new ResponseEntity<>(new CustomErrorType("Unable to create because unique constraint violation- Customer"),HttpStatus.CONFLICT);
//	
//			Customer savedCustomer=service.createNewCustomer(cust);
//			response=new ResponseEntity<>(savedCustomer,HttpStatus.CREATED);

		return service.addCustomer(request.getCustomer());
		
	}
	@GetMapping("/customer")
	public List<Customer> findAllCustmers(){
		return service.findAllCustomers();
	}
	

	@PutMapping("/customer/{id}")
	public ResponseEntity<?> updateCustomer(@PathVariable int id,@RequestBody Customer cust){
		ResponseEntity<?> response=new ResponseEntity<>(new CustomErrorType("Updation failed since given ID not found"),HttpStatus.NOT_FOUND);
//		 return service.updateCustomer(id);
		boolean isCustumerPresent=service.isCustomerPresent(id);
		if(isCustumerPresent) {
			service.updateCustomer(id,cust);
			response=ResponseEntity.ok("Updation Successfull");
		}
		return response;
	}
	@DeleteMapping("/customer/{id}")
	public ResponseEntity<?> deleteCustomer(@PathVariable int id){
		ResponseEntity<?> response=new ResponseEntity<>(new CustomErrorType("Deletion failed since given ID not found"),HttpStatus.NOT_FOUND);
		boolean isCustumerPresent=service.isCustomerPresent(id);
		if(isCustumerPresent) {
			service.deleteCustomer(id);
			response=ResponseEntity.ok("Deletion Successfull");
		}
		return response;			
	}
	
}
