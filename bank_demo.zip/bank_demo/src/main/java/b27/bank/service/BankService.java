package b27.bank.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import b27.bank.dao.AccountRepository;
import b27.bank.dao.CustomerRepository;
import b27.bank.domain.Account;
import b27.bank.domain.Customer;

@Service
public class BankService {
	
	@Autowired
	AccountRepository acctRepo;
	
	@Autowired
	CustomerRepository custRepo;
	
	public Account createNewAccount(Account acct) {
		
		return acctRepo.save(acct);
	}
	public Customer createNewCustomer(Customer cust) {
		
		return custRepo.save(cust);
	}
	
	public Optional<Account> findByAccountId(int acctid) {
		//If joint account display both names else display 1 name

		return acctRepo.findById(acctid);
	}
	public boolean isAccountPresent(int acctid) {
		return acctRepo.findById(acctid).isPresent();
	}
	
	public List<Account> findAllAccounts(){
		return acctRepo.findAll();
		
	}
	
	public boolean isCustomerPresent(int custid) {
		return custRepo.findById(custid).isPresent();
	}

	
	public int transferFund(int fromAccount,int toAccount,double amount) {
		int result;
		boolean fromAccountFound=isAccountPresent(fromAccount);
		boolean toAccountFound=isAccountPresent(toAccount);

		if(!fromAccountFound) {
			result=1;
			return result;
		}
		Account fromAcct=findByAccountId(fromAccount).get();
		double fromAcctbalance=fromAcct.getBalance();
		if(fromAcctbalance<amount) {
			result=2;
		}
		else if(!toAccountFound) {
			result=3;
		}
		else {
			
			Account toAcct=findByAccountId(fromAccount).get();
			double toAcctbalance=toAcct.getBalance();
			toAcct.setBalance(toAcctbalance+amount);
			fromAcct.setBalance(fromAcctbalance-amount);
			 acctRepo.save(fromAcct);
			 acctRepo.save(toAcct);
			result=0;
			
		}
		return result;
	}
	public Customer addCustomer(Customer cust) {
		
		return custRepo.save(cust);
	}
	public List<Customer> findAllCustomers(){
		return custRepo.findAll();
	}
	public Customer findCustomer(int id){
		return (custRepo.findById(id).get());
	}
	public void updateCustomer(int id,Customer cust) {
		// TODO Auto-generated method stub
//		Customer updated=findCustomer(id);
//		updated.setFullName(null);
//		updated.setAccounts(null);
//		updated.setAddress(null);
//		updated.
		cust.setId(id);
		custRepo.save(cust);
		
	}
	public void deleteCustomer(int id) {
		// TODO Auto-generated method stub
		custRepo.deleteById(id);
	}
}
