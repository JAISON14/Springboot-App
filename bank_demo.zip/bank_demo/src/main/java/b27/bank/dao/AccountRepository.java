package b27.bank.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import b27.bank.domain.Account;

@Repository
public interface AccountRepository extends JpaRepository<Account,Integer>{

}
