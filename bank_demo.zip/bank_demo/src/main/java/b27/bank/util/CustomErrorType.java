package b27.bank.util;

public class CustomErrorType {

	String errorMessage;
	
	public CustomErrorType(String errorMessage) {
		this.errorMessage=errorMessage;
	}
	public String getErrorMessage() {
		return errorMessage;
	}
}
